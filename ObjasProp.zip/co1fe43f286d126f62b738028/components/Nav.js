import React from "react"
export default function Nav () {
    return (
        <div className="NavContainer">
        <div className="navBar">
        <i className="fas fa-globe-americas gg"></i>
        <div className="Nav-Text">Pyae Phyo Thant's travel journal.</div>
        </div>
        </div>
    )
}